<?php
	echo 'dummy page.';
?>
